import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { RouterModule } from '@angular/router';

import { CategoryService } from '../../../services/category.service';
import { MaintenanceRequestService } from '../../../services/maintenance-request.service';
import { QuoteService } from '../../../services/quote.service';

import { Category } from '../../../shared/models/category.model';
import { RequestStatus } from '../../../shared/enum/request-status.enum';

@Component({
  selector: 'app-view-revenue-report-by-category',
  imports: [
    CommonModule,
    RouterModule
  ],
  templateUrl: './view-revenue-report-by-category.component.html',
  styleUrl: './view-revenue-report-by-category.component.css',
})
export class ViewRevenueReportByCategoryComponent implements OnInit {

  revenueByCategory: {
    category: Category;
    requestsCount: number;
    total: number;
  }[] = [];

  totalRevenue: number = 0;

  message: string = '';

  constructor(
    private categoryService: CategoryService,
    private maintenanceRequestService: MaintenanceRequestService,
    private quoteService: QuoteService
  ) {}

  ngOnInit(): void {
    this.generateReport();
  }

  generateReport(): void {

    this.revenueByCategory = [];
    this.totalRevenue = 0;
    this.message = '';

    const categories =
      this.categoryService.listAll();

    const requests =
      this.maintenanceRequestService
        .listAll()
        .filter(request =>
          request.status === RequestStatus.PAID ||
          request.status === RequestStatus.FINALIZED
        );

    categories.forEach(category => {

      const categoryRequests =
        requests.filter(
          request =>
            request.categoryId === category.id
        );

      let categoryRevenue = 0;

      categoryRequests.forEach(request => {

        const quote =
          this.quoteService.findByRequestId(
            request.id
          );

        if (quote) {
          categoryRevenue += quote.price;
        }

      });

      this.revenueByCategory.push({
        category: category,
        requestsCount: categoryRequests.length,
        total: categoryRevenue
      });

      this.totalRevenue += categoryRevenue;
    });

    if (this.totalRevenue === 0) {
      this.message =
        'Nenhuma receita encontrada.';
    }
  }

  printReport(): void {

    if (this.totalRevenue === 0) {

      this.message =
        'Não existem receitas para gerar o relatório.';

      return;
    }

    window.print();
  }
}