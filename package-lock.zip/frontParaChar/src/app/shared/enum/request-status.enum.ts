export enum RequestStatus {
  OPEN = 'OPEN',
  QUOTED = 'QUOTED',
  APPROVED = 'APPROVED',
  REJECTED = 'REJECTED',
  REDIRECTED = 'REDIRECTED',
  FIXED = 'FIXED',
  PAID = 'PAID',
  FINALIZED = 'FINALIZED',
}
